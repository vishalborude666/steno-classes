﻿This font is provided from online source. If this font is owned by you do lets us know with more details. We will remove remove it ASAP after confirmation. 

